"""
DeltaOptimizer examples - Quick start and advanced usage.
"""

from .quick_start import *
from .advanced_usage import *