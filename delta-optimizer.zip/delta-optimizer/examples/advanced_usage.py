"""
Advanced DeltaOptimizer Usage
Custom configurations and advanced features.
"""

import torch
import torch.nn as nn
from delta_optimizer import DeltaOptimizer, create_dashboard, save_report

# 1. Custom Δ† parameters for different scenarios
configs = {
    # For fast-changing datasets
    'aggressive': {
        'delta_high': 0.08,
        'delta_low': 0.02,
        'lr_increase': 1.5,
        'lr_decrease': 0.6
    },
    # For stable datasets
    'conservative': {
        'delta_high': 0.03,
        'delta_low': 0.005,
        'lr_increase': 1.1,
        'lr_decrease': 0.9
    },
    # For transfer learning
    'fine_tuning': {
        'delta_high': 0.02,
        'delta_low': 0.001,
        'lr_increase': 1.05,
        'lr_decrease': 0.95
    }
}

# 2. Choose configuration based on your use case
config = configs['conservative']

# 3. Initialize with custom parameters
optimizer = DeltaOptimizer(
    torch.optim.Adam(model.parameters(), lr=0.001),
    model=model,
    **config  # Pass custom configuration
)

# 4. Manual Δ† monitoring and intervention
for epoch in range(epochs):
    # ... training code ...
    
    current_lr = optimizer.step(loss.item(), accuracy)
    
    # Monitor Δ† values and take custom actions
    current_delta = optimizer.history['deltas'][-1]
    
    if current_delta > 0.1:  # Very high Δ†
        print("⚠️  High learning potential detected!")
        # Add custom logic here
        
    elif current_delta < 0.001:  # Very low Δ†
        print("⚠️  Learning stagnation detected!")
        # Add custom logic here

# 5. Save detailed report
save_report(optimizer.history, 'training_report.json')

# 6. Access raw statistics
stats = optimizer.get_stats()
print(f"""
📊 Training Statistics:
✅ Initial LR: {stats['initial_lr']:.6f}
✅ Final LR: {stats['current_lr']:.6f}
✅ LR Changes: {stats['lr_changes']}
✅ Max Δ†: {stats['max_delta']:.4f}
✅ Accuracy Improvement: {stats['improvement']:.2f}%
""")

# 7. Reset for new training
# optimizer.history.clear()  # Start fresh