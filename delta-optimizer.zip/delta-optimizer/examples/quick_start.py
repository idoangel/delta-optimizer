"""
DeltaOptimizer Quick Start Guide
5-minute tutorial to get started with automatic AI training optimization.
"""

import argparse
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from delta_optimizer import DeltaOptimizer, create_dashboard

def main(dry_run=False):
    """Main training function with dry-run support."""
    
    # 1. Define your model (any architecture works!)
    class SimpleCNN(nn.Module):
        def __init__(self):
            super(SimpleCNN, self).__init__()
            self.conv1 = nn.Conv2d(1, 32, 3, 1)
            self.conv2 = nn.Conv2d(32, 64, 3, 1)
            self.fc = nn.Linear(9216, 10)

        def forward(self, x):
            x = torch.relu(self.conv1(x))
            x = torch.relu(self.conv2(x))
            x = torch.flatten(x, 1)
            return self.fc(x)

    if dry_run:
        print("✅ Dry run successful - all imports work correctly!")
        return

    # 2. Set up your data and training as usual
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])

    train_dataset = datasets.MNIST('./data', train=True, download=True, transform=transform)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=64, shuffle=True)

    # 3. Create your model and optimizer
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SimpleCNN().to(device)
    criterion = nn.CrossEntropyLoss()

    # 4. 🔁 REPLACE THIS LINE:
    # optimizer = optim.Adam(model.parameters(), lr=0.001)

    # 5. ✅ WITH THIS LINE:
    optimizer = DeltaOptimizer(
        optim.Adam(model.parameters(), lr=0.001),
        model=model
    )

    # 6. Train as usual - just add accuracy tracking
    for epoch in range(3):  # Just 3 epochs for demo
        model.train()
        total_loss = 0
        correct = 0
        
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            
            # Calculate accuracy
            pred = output.argmax(dim=1)
            accuracy = 100. * pred.eq(target).sum().item() / target.size(0)
            
            # 🔁 REPLACE: optimizer.step()
            # ✅ WITH: current_lr = optimizer.step(loss.item(), accuracy)
            current_lr = optimizer.step(loss.item(), accuracy)
            
            total_loss += loss.item()
            correct += pred.eq(target).sum().item()
            
            if batch_idx % 100 == 0:
                print(f'Epoch {epoch}, Batch {batch_idx}, Loss: {loss.item():.4f}, Acc: {accuracy:.2f}%, LR: {current_lr:.6f}')

    # 7. View results
    print(f"\n🎉 Training completed!")
    print(f"Final Accuracy: {100. * correct / len(train_dataset):.2f}%")
    print(f"Learning Rate Changes: {len(set(optimizer.history['lrs']))}")

    # 8. Create dashboard
    create_dashboard(optimizer.history, 'quick_start_results.png')

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DeltaOptimizer Quick Start")
    parser.add_argument('--dry-run', action='store_true', help='Test imports without training')
    args = parser.parse_args()
    
    main(dry_run=args.dry_run)