import numpy as np
import logging
from typing import Dict, Tuple

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DeltaOptimizerCore:
    """Core Δ† computation engine."""
    
    def __init__(self, alpha: float = 0.8, beta: float = 2.5, C: float = 1.0):
        self.alpha = alpha
        self.beta = beta
        self.C = C
        self.moving_max_a = 1.0
        self.moving_max_b = 1.0
        
    def compute_delta_dagger(self, a_t: float, b_t: float) -> float:
        """Compute Δ† value using the super-equation."""
        if a_t <= 1e-6 or b_t <= 1e-6:
            return 0.0
        
        T = self.C * (a_t * b_t)
        sin_term = np.sin(np.pi * a_t * b_t)
        saturation = 1 - np.exp(-self.alpha * (a_t + b_t) * T)
        regulator = np.sqrt(a_t * b_t * saturation)
        enablement = 1 - np.exp(-self.beta * a_t)
        
        result = sin_term * saturation * regulator * enablement
        return float(result) if not np.isnan(result) else 0.0
    
    def update_moving_max(self, a_t: float, b_t: float) -> Tuple[float, float]:
        """Update moving maximum values and return normalized values."""
        self.moving_max_a = max(self.moving_max_a, a_t)
        self.moving_max_b = max(self.moving_max_b, b_t)
        
        a_norm = a_t / self.moving_max_a if self.moving_max_a > 1e-6 else 0.0
        b_norm = b_t / self.moving_max_b if self.moving_max_b > 1e-6 else 0.0
        
        return a_norm, b_norm