import torch
import torch.nn as nn
import numpy as np
from typing import Optional, Dict, Tuple, Any
from .core import DeltaOptimizerCore

class DeltaOptimizer(DeltaOptimizerCore):
    """
    Drop-in replacement for PyTorch optimizers with automatic learning rate adjustment.
    
    Example:
        from delta_optimizer import DeltaOptimizer
        import torch
        
        # Replace this:
        # optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        
        # With this:
        optimizer = DeltaOptimizer(
            torch.optim.Adam(model.parameters(), lr=0.001),
            model=model
        )
        
        # Use exactly like normal optimizer
        optimizer.zero_grad()
        loss.backward()
        optimizer.step(loss, accuracy=accuracy)  # Add loss and optional accuracy
    """
    
    def __init__(self, optimizer: torch.optim.Optimizer, model: nn.Module,
                 delta_high: float = 0.05, delta_low: float = 0.01,
                 lr_increase: float = 1.2, lr_decrease: float = 0.7,
                 **kwargs):
        
        super().__init__(**kwargs)
        self.optimizer = optimizer
        self.model = model
        self.delta_high = delta_high
        self.delta_low = delta_low
        self.lr_increase = lr_increase
        self.lr_decrease = lr_decrease
        
        self.history = {
            'deltas': [], 'losses': [], 'lrs': [], 
            'accuracies': [], 'gradient_diversity': []
        }
        self.initial_lr = optimizer.param_groups[0]['lr']
        
    def compute_gradient_diversity(self) -> float:
        """Compute gradient diversity metric (a_t)."""
        grads = []
        for param in self.model.parameters():
            if param.grad is not None:
                grads.append(param.grad.view(-1))
        
        if not grads:
            return 0.0
            
        grads = torch.cat(grads)
        if len(grads) < 2:
            return 0.0
            
        grad_std = torch.std(grads)
        grad_mean_abs = torch.mean(torch.abs(grads))
        diversity = (grad_std / (grad_mean_abs + 1e-7)).item()
        
        return diversity if not np.isnan(diversity) else 0.0
    
    def step(self, loss: float, accuracy: Optional[float] = None) -> float:
        """
        Perform optimization step with automatic learning rate adjustment.
        
        Args:
            loss: Current loss value
            accuracy: Optional accuracy value for tracking
            
        Returns:
            Current learning rate after adjustment
        """
        # Store previous loss for comparison
        previous_loss = self.history['losses'][-1] if self.history['losses'] else loss
        
        # Compute metrics
        a_t = self.compute_gradient_diversity()
        b_t = abs(previous_loss - loss)
        
        # Handle edge cases
        if np.isnan(a_t) or a_t < 0:
            a_t = 0.0
        if np.isnan(b_t) or b_t < 0:
            b_t = 0.0
        
        # Normalize and compute Δ†
        a_norm, b_norm = self.update_moving_max(a_t, b_t)
        
        if a_norm < 1e-6 or b_norm < 1e-6:
            delta = 0.0
        else:
            delta = self.compute_delta_dagger(a_norm, b_norm)
            if np.isnan(delta) or delta < 0:
                delta = 0.0
        
        # Adjust learning rate based on Δ†
        current_lr = self.optimizer.param_groups[0]['lr']
        new_lr = current_lr
        
        if delta > self.delta_high:
            new_lr = min(current_lr * self.lr_increase, self.initial_lr * 10)
        elif delta < self.delta_low:
            new_lr = max(current_lr * self.lr_decrease, self.initial_lr * 0.001)
        
        # Apply learning rate change
        if new_lr != current_lr:
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = new_lr
        
        # Store history
        self.history['deltas'].append(delta)
        self.history['losses'].append(loss)
        self.history['lrs'].append(new_lr)
        self.history['gradient_diversity'].append(a_t)
        if accuracy is not None:
            self.history['accuracies'].append(accuracy)
        
        # Perform the actual optimization step
        self.optimizer.step()
        
        return new_lr
    
    def zero_grad(self):
        """Clear gradients - same as underlying optimizer."""
        self.optimizer.zero_grad()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get optimization statistics."""
        return {
            'initial_lr': self.initial_lr,
            'current_lr': self.history['lrs'][-1] if self.history['lrs'] else self.initial_lr,
            'lr_changes': len(set(self.history['lrs'])),
            'max_delta': max(self.history['deltas']) if self.history['deltas'] else 0.0,
            'final_accuracy': self.history['accuracies'][-1] if self.history['accuracies'] else None,
            'improvement': self._calculate_improvement()
        }
    
    def _calculate_improvement(self) -> float:
        """Calculate overall improvement if accuracy data is available."""
        if len(self.history['accuracies']) > 1:
            return self.history['accuracies'][-1] - self.history['accuracies'][0]
        return 0.0