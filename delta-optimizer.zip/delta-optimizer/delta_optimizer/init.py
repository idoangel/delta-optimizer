"""
DeltaOptimizer - Autonomous AI Training Optimization
Drop-in replacement for PyTorch optimizers with automatic learning rate adjustment.
"""

from .torch_optimizer import DeltaOptimizer
from .utils import create_dashboard, save_report

__version__ = "1.0.0"
__author__ = "Ido Angel"
__email__ = "ai@idoangel.com"

__all__ = ['DeltaOptimizer', 'create_dashboard', 'save_report']