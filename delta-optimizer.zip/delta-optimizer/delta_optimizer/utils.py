import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, Any
import json
from datetime import datetime

def create_dashboard(history: Dict[str, Any], save_path: str = None):
    """Create visualization dashboard for training results."""
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    # Δ† plot
    axes[0, 0].plot(history['deltas'], 'b-', linewidth=2)
    axes[0, 0].set_title('Δ† Values')
    axes[0, 0].grid(True, alpha=0.3)
    
    # Loss plot
    axes[0, 1].plot(history['losses'], 'r-', linewidth=2)
    axes[0, 1].set_title('Training Loss')
    axes[0, 1].grid(True, alpha=0.3)
    
    # Accuracy plot (if available)
    if history['accuracies']:
        axes[0, 2].plot(history['accuracies'], 'g-', linewidth=2)
        axes[0, 2].set_title('Accuracy (%)')
    axes[0, 2].grid(True, alpha=0.3)
    
    # Learning Rate plot
    axes[1, 0].plot(history['lrs'], 'm-', linewidth=2)
    axes[1, 0].set_title('Learning Rate')
    axes[1, 0].grid(True, alpha=0.3)
    
    # Gradient Diversity plot
    axes[1, 1].plot(history['gradient_diversity'], 'c-', linewidth=2)
    axes[1, 1].set_title('Gradient Diversity')
    axes[1, 1].grid(True, alpha=0.3)
    
    # Hide empty subplot
    axes[1, 2].set_visible(False)
    
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()

def save_report(history: Dict[str, Any], filepath: str):
    """Save training report to JSON file."""
    report = {
        'timestamp': datetime.now().isoformat(),
        'stats': {
            'max_delta': max(history['deltas']) if history['deltas'] else 0.0,
            'final_accuracy': history['accuracies'][-1] if history['accuracies'] else None,
            'lr_changes': len(set(history['lrs'])),
            'final_lr': history['lrs'][-1] if history['lrs'] else 0.0
        },
        'history': {k: v for k, v in history.items() if k != 'gradient_diversity'}  # Skip large arrays
    }
    
    with open(filepath, 'w') as f:
        json.dump(report, f, indent=2)